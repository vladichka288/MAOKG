# Лабораторна робота №5

## Бухаленков Дмитро КП-81 (варіант 1):

Importing .obj file, Paper Ship in the puddle

## Результат:

![resultimage](shipdemo1.gif)

